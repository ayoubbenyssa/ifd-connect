import 'dart:collection';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter_slidable/flutter_slidable.dart';

//import 'package:ifdconnect/campus/shared/fixdropdown.dart';
import 'package:ifdconnect/models/MealList.dart';
import 'package:ifdconnect/models/Mealcal.dart';
import 'package:ifdconnect/models/type_composant.dart';
import 'package:ifdconnect/models/type_ropa.dart';
import 'package:ifdconnect/restauration/meal_day_widget.dart';
import 'package:ifdconnect/services/Fonts.dart';
import 'package:intl/intl.dart';
import 'package:ifdconnect/models/meal.dart';
import 'package:ifdconnect/restauration/Resto.dart';

import 'package:sticky_headers/sticky_headers.dart';

class AllReservations extends StatefulWidget {
  final int _userId;
  final int _studentId;
  final int _token;

  AllReservations(this._userId, this._studentId, this._token);

  @override
  _MesReservationState createState() => _MesReservationState();
}

class _MesReservationState extends State<AllReservations> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  var reservationData;
  var dataDay;
  var data;
  List meals = [];
  List<MealOneItem> listmeals = [];
  bool loading = true;
  String date;
  bool check_all = false;
  var date_deb = DateFormat('yyyy-MM-dd')
      .format(new DateTime.now().add(new Duration(days: 1)));
  var date_fin = DateFormat('yyyy-MM-dd')
      .format(new DateTime.now().add(new Duration(days: 200)));
  String name_repas = "Tout";
  var mealsmap = new SplayTreeMap<String, Object>();
  List<int> mealsTrue = [];
  int index = 1;
  List listKey = [];
  List<Meal> _list = [];
  SlidableController ctrl;
  int i = 0;
  List<int> tikeckids = [];
  Key keys;
  bool test22 = false;

  List<MealCal> mealCal = [];
  var composants_id;
  List Extra;
  List composont;

  List mealcal = [
    {"MealCal": ""},
    {"extra": []},
    {"composants": []},
  ];

  SelectAll(){
    check_all = !check_all;
    for(MealOneItem elem in listmeals){
      for(MealCal meal in elem.meals){
        if (check_all) {
          meal.is_student_reserved ? MealOneItem.annulations.add(meal.ticket_id) : MealOneItem.reservations.add(meal.pricemeal_id);
        }
        else
          meal.is_student_reserved ? MealOneItem.annulations.remove(meal.ticket_id) : MealOneItem.reservations.remove(meal.pricemeal_id);

        meal.check = check_all;
      }
    }
    setState(() {

    });
  }

  //fonction pour adapter format d'affichage d'une date
  String _formatDate(String date) {
    String day = DateTime.parse(date).day.toString();
    String month = DateTime.parse(date).month.toString();
    String year = DateTime.parse(date).year.toString();
    String m = int.parse(month) < 10 ? "0$month" : "$month";
    String d = int.parse(day) < 10 ? "0$day" : "$day";

    return "$d/$m/$year";
  }

  //service pour annuler un repas
  Future<http.Response> makeCancel(
      int user_id, int student_id, int token, String ticketId) async {
    final param = {
      "user_id": "$user_id",
      "student_id": "$student_id",
      "auth_token": "$token",
      "tickets_ids": "$ticketId"
    };

    final reservationsData = await http.post(
      "http://ifd-erp.tk/api/make_cancellation",
      body: param,
    );
    print('vava2');
    print(MealOneItem.annulations);
    print(json.decode(reservationsData.body));
    setState(() {
      data = json.decode(reservationsData.body);
    });

    return reservationsData;
  }

  Future<List<Meal>> get_meals(int user_id, int student_id, int token) async {
    final param = {
      "user_id": "$user_id",
      "student_id": "$student_id",
      "auth_token": "$token",
    };

    final reservationsData = await http.post(
      "http://ifd-erp.tk/api/meals",
      body: param,
    );
    List list = [];
    if (this.mounted) {
      setState(() {
        list = json.decode(reservationsData.body)["meals"];
      });
    }

    return list.map((contactRaw) => new Meal.fromDoc(contactRaw)).toList();
  }

  bool wait = false;

  //service pour réserver un repas
  Future<http.Response> makeReservationConf(
      int user_id, int student_id, int token, String pmIds) async {
    final param = {
      "user_id": "$user_id",
      "student_id": "$student_id",
      "auth_token": "$token",
      "pm_ids": "$pmIds",
    };

    final restoData = await http.post(
      "http://ifd-erp.tk/api/make_reservation",
      body: param,
    );

    setState(() {
      reservationData = json.decode(restoData.body);
      setState(() {
        wait = false;
      });
    });
    print('vava');
    print(reservationData);

    if (reservationData["result"] == false) {
      _showDialog();
    }

    return restoData;
  }

  void _showDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        // return object of type Dialog
        return AlertDialog(
          title: Text(
            "OUPS !",
            style: TextStyle(color: Colors.red),
          ),
          content: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                  "Votre solde est insuffisant pour effectuer cette operation"),
              Text(""),
              Text(
                  "Votre solde actuel : ${reservationData["current_amount"]} DHS "),
            ],
          ),
          actions: <Widget>[
            // usually buttons at the bottom of the dialog
            Container(
              decoration: BoxDecoration(
                  color: Fonts.col_app,
                  borderRadius: BorderRadius.circular(10.0)),
              child: new FlatButton(
                child: new Text(
                  "OK",
                  style: TextStyle(color: Colors.white),
                ),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ),
          ],
        );
      },
    );
    // flutter defined function
  }

  Future<http.Response> getMeals(int user_id, int student_id, int token,
      String start_date, String end_date) async {
    final param = {
      "user_id": "$user_id",
      "student_id": "$student_id",
      "auth_token": "$token",
      "start_date": "$start_date",
      "end_date": "$end_date",
      "meal_id": "all",
      "is_reserved": "all"
    };

    final mealsData = await http.post(
      "http://ifd-erp.tk/api/all_meals_calendar",
      body: param,
    );

    // print(mealsData.body);

    if (this.mounted)
      setState(() {
        data = json.decode(mealsData.body);
      });

    // print(data['result'][0]['27'][0]['type_composant'][0]["composants"]);

    // mealCal = data.map
    return mealsData;
  }

  getMealsCal() {
    if (!this.mounted) return;
    print("jsjsjsjjsjsjsjsjj-------------------------------");

    //print(data["result"]);


    print('laliste');
    print(data['result']);
    setState(() {
      data["result"][0].forEach((key, value) => listmeals.add(MealOneItem.fromDoc(key.toString(), value)));

    });


    /*List<MealOneItem> list = List<MealOneItem>.from(data["result"]
        .map((val) => MealOneItem.fromDoc(val.keys.first, val))
        .toList());

    setState(() {
      listmeals = list;
    });
*/
    print(listmeals);

    /* for (var i = 0; i < data["result"].length; i++) {
      for (var key in data["result"][i].keys) {
        meals = [];
        for (var j = 0; j < data["result"][i][key].length; j++) {
          date = data["result"][i][key][j]["start_date"];
          List test = [];
          List test2 = [];

          mealsTrue = [];


          test.add(data["result"][i][key][j]["ticket"]);

          var meal = MealCal.fromDoc(data["result"][i][key][j]);

          if (meal.is_student_reserved == true) {
            mealsTrue.add(index);
          }
          index++;
          meals.add(meal);
        }
        mealsmap["$date"] = meals;
      } //end for key
    } */ //end for i

    //  listmeals.add(mealsmap);

    getKey();
    loading = false;
  }

  getKey() {
    for (var k in listmeals) {
      listKey.add(k.date);
    }
    listKey = listKey.reversed.toList();
  }

  void handleSlideAnimationChanged(Animation<double> slideAnimation) {
    setState(() {
      //  _rotationAnimation = slideAnimation;
    });
  }

  void handleSlideIsOpenChanged(bool isOpen) {
    setState(() {
      //_fabColor = isOpen ? Colors.green : Colors.blue;
    });
  }

  @override
  void initState() {
    MealOneItem.annulations = [];
    MealOneItem.reservations = [];
    ctrl = SlidableController(
      onSlideAnimationChanged: handleSlideAnimationChanged,
      onSlideIsOpenChanged: handleSlideIsOpenChanged,
    );
    // print("test date ====${DateTime.fromMillisecondsSinceEpoch(1653562444 * 1000)}");

    String today = DateTime.now().add(new Duration(days: -90)).toString();

    getMeals(
            widget._userId,
            widget._studentId,
            widget._token,
            new DateFormat('yyyy-MM-dd')
                .format(new DateTime.now().add(new Duration(days: -90))),
            addDays(today, 10))
        .then((_) {
      getMealsCal();
    });

    get_meals(widget._userId, widget._studentId, widget._token).then((val) {
      if (this.mounted)
        setState(() {
          _list = val;
        });
    });
    super.initState();
  }

  clear() async {
    setState(() {
      _list = [];
      loading = true;
    });
    String today = DateTime.now().add(new Duration(days: 1)).toString();

    getMeals(
            widget._userId,
            widget._studentId,
            widget._token,
            new DateFormat('yyyy-MM-dd')
                .format(new DateTime.now().add(new Duration(days: 1))),
            addDays(today, 200))
        .then((_) {
      getMealsCal();
    });

    get_meals(widget._userId, widget._studentId, widget._token).then((val) {
      if (this.mounted)
        setState(() {
          _list = val;
        });
    });
  }

  bool containsElement(int id) {
    for (var i = 0; i < mealsTrue.length; i++) {
      if (id == mealsTrue[i]) return true;
    }
    return false;
  }

  String addDays(String date, int nbrDays) {
    var parsedDate = DateTime.parse(date);
    var myDate = parsedDate.add(new Duration(days: nbrDays));
    String day = myDate.day.toString();
    String month = myDate.month.toString();
    String year = myDate.year.toString();
    String m = int.parse(month) < 10 ? "0$month" : "$month";
    String d = int.parse(day) < 10 ? "0$day" : "$day";

    return "$year-$m-$d";
  }

  isBefore(String date) {
    List<String> res = date.split("-");
    bool value = DateTime.now().isBefore(DateTime(
            int.parse(res[0]), int.parse(res[1]), int.parse(res[2]) - 1))
        ? false
        : true;
    return value;
  }

  Future<http.Response> get__Meals(int user_id, int student_id, int token,
      String start_date, String end_date, sel_id) async {
    meals = [];
    listmeals = [];
    mealsmap = new SplayTreeMap<String, Object>();
    mealsTrue = [];
    listKey = [];

    final param = {
      "user_id": "$user_id",
      "student_id": "$student_id",
      "auth_token": "$token",
      "start_date": "$start_date",
      "end_date": "$end_date",
      "meal_id": "$sel_id"
    };

    final mealsData = await http.post(
      "http://ifd-erp.tk/api/all_meals_calendar",
      body: param,
    );

    setState(() {
      data = json.decode(mealsData.body);
    });

    /* Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => AllMealsCalendar(
                data, widget._userId, widget._studentId, widget._token)));*/

    return mealsData;
  }

  _showDialogDate() async {
    return await showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => new AlertDialog(
              elevation: 0.0,
              shape: RoundedRectangleBorder(
                  side: BorderSide(color: Fonts.col_app_fonn),
                  borderRadius: BorderRadius.circular(18.r)),
              title: Container(
                decoration: BoxDecoration(),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        IconButton(
                            icon: Icon(
                              Icons.close,
                              size: 20.r,
                              color: Fonts.col_grey,
                            ),
                            onPressed: () {
                              Navigator.pop(context);
                            }),
                      ],
                    ),
                    Text(
                      "La période du réservation : ",
                      style: TextStyle(
                          color: Fonts.col_app_fonn,
                          fontWeight: FontWeight.bold,
                          fontSize: 18.sp),
                    )
                  ],
                ),
              ),
              content: ListMeals(
                widget._userId,
                widget._studentId,
                widget._token,
                this._list,
              ),
            ));
  }

  // flutter defined function

  filter_meal() async {
    List a = await _showDialogDate();

    print("********************Liste des repas");
    print(a);
    print("********************Liste des repas");
    if (a.toString() != "null") {
      setState(() {
        loading = true;
      });

      print("yess");
      setState(() {
        date_deb = a[3];
        date_fin = a[4];
        name_repas = a[6];
      });

      await get__Meals(a[0], a[1], a[2], a[3], a[4], a[5]);
      await getMealsCal();

      setState(() {
        loading = false;
      });
    }
  }

  /* change(value) {
    print("aaaaaaaaaaaa");
    print(value);
    if (value == true) {
      setState(() {
        check_all = true;
      });
      print(
          "------------_________________-----------______________-----------");
      print(listmeals[0]);
      for (var i in listKey) {
        listmeals[0][i].forEach((val) {
          setState(() {
            val.check = true;
          });
          if (!priceIds.contains(int.parse(val.pricemeal_id.toString()))) {
            priceIds.add(int.parse(val.pricemeal_id.toString()));
          }

          if (!tikeckids.contains(val.ticket_id) &&
              val.ticket_id.toString() != "null") {
            tikeckids.add(val.ticket_id);
          }

          //tikeckids
        });
      }
    } else {
      setState(() {
        check_all = false;
      });
      for (var i in listKey) {
        listmeals[0][i].forEach((val) {
          setState(() {
            val.check = false;
          });
          if (priceIds.contains(int.parse(val.pricemeal_id.toString()))) {
            priceIds.remove(int.parse(val.pricemeal_id.toString()));
          }

          if (tikeckids.contains(val.ticket_id)) {
            tikeckids.remove(val.ticket_id);
          }
        });
      }
    }
  }*/

  Widget preferredSize(hieght) {
    return PreferredSize(
      preferredSize: Size.fromHeight(hieght),
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 5.w, horizontal: 10.h),
        child: Column(children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                // color: Colors.white,
                margin: EdgeInsets.symmetric(vertical: 10.h),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(19.r)),
                    border: Border.all(
                        style: BorderStyle.solid, color: Fonts.border_col)),
                padding: EdgeInsets.symmetric(vertical: 6.h, horizontal: 12.w),
                // decoration: BoxDecoration(border: Border.all(color: Colors.red)),
                child: Row(
                  children: [
                    Container(
                      child: Text("De: ",
                          style: TextStyle(
                              color: Fonts.col_app_grey, fontSize: 12.sp)),
                    ),
                    Container(
                      child: Text("${date_deb}",
                          style: TextStyle(
                              color: Fonts.col_app_grey, fontSize: 12.sp)),
                    ),
                  ],
                ),
              ),
              Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(19.r)),
                    border: Border.all(
                        style: BorderStyle.solid, color: Fonts.border_col)),
                padding: EdgeInsets.symmetric(vertical: 6.h, horizontal: 12.w),
                child: Row(
                  children: [
                    Container(
                      child: Text(
                        "À : ",
                        style: TextStyle(
                            color: Fonts.col_app_grey, fontSize: 12.sp),
                      ),
                    ),
                    Container(
                      child: Text("${date_fin}",
                          style: TextStyle(
                              color: Fonts.col_app_grey, fontSize: 12.sp)),
                    )
                  ],
                ),
              ),
              Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(19.r)),
                    border: Border.all(
                        style: BorderStyle.solid, color: Fonts.border_col)),
                padding: EdgeInsets.symmetric(vertical: 6.h, horizontal: 12.w),
                child: Row(
                  children: [
                    Container(
                      child: Text("Repas : ",
                          style: TextStyle(
                              color: Fonts.col_app_grey, fontSize: 12.sp)),
                    ),
                    Container(
                      child: Text("${name_repas}",
                          style: TextStyle(
                              color: Fonts.col_app_grey, fontSize: 12.sp)),
                    ),
                  ],
                ),
              ),
            ],
          ),
          // Container(
          //   height: 12.h,
          // ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              InkWell(
                  child: Container(
                      width: MediaQuery.of(context).size.width * 0.57,
                      // color: Colors.white,
                      // decoration: BoxDecoration(border: Borde),
                      padding:
                          EdgeInsets.symmetric(vertical: 1.h, horizontal: 5.w),
                      // decoration: BoxDecoration(border: Border.all(color: Colors.red)),

                      child: new Container(
                          // padding: EdgeInsets.symmetric(vertical: 6.h,horizontal: 6.w),
                          decoration: new BoxDecoration(
                              color: Fonts.col_app_fon,
                              border: new Border.all(
                                  color: Fonts.border_col, width: 1.0),
                              borderRadius: new BorderRadius.circular(19.0.r)),
                          child: Row(
                            children: [
                              SizedBox(
                                width: 5.r,
                              ),
                              Container(
                                child: Icon(
                                  Icons.settings,
                                  size: 20.r,
                                  color: Colors.white,
                                ),
                              ),
                              SizedBox(
                                width: 5.r,
                              ),
                              Container(
                                child: Text("Filtrer les repas par :",
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 12.0.sp)),
                              ),
                              Expanded(
                                child: Container(),
                              ),
                              Container(
                                child: Icon(
                                  Icons.arrow_drop_down,
                                  size: 35.r,
                                  color: Colors.white,
                                ),
                              ),
                            ],
                          ))),
                  onTap: () {
                    filter_meal();
                  }),
              FlatButton(
                  onPressed: () {
                    clear();
                  },
                  child: Row(
                    children: [
                      Icon(
                        Icons.close,
                        color: Fonts.col_app_red,
                      ),
                      Text(
                        "Effacer le filtre",
                        style: TextStyle(
                            color: Fonts.col_app_red, fontSize: 12.sp),
                      )
                    ],
                  )),
            ],
          ),
          Divider(
            color: Fonts.col_grey,
            thickness: 0.5,
          ),
        ]),
      ),
    );
  }

  annuler() async {

    if (wait == false) {
      if (MealOneItem.annulations.length == 0) {
        MealOneItem.reservations.length==0 ? ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Aucun repas n'est sélectionné"))) : ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Les repas sélectionnés ne sont pas déjà réservés")));
        // setState(() {
        //   wait = false;
        // });
      } else {
        setState(() {
          wait = true;
        });
        await makeCancel(widget._userId, widget._studentId, widget._token,
            MealOneItem.annulations.join(","))
            .then((_) {
          for(MealOneItem meal in listmeals){
            meal.meals.forEach((val) {
              if (MealOneItem.annulations.contains(val.ticket_id))
                setState(() {
                  val.is_student_reserved = false;
                  val.check = false;
                });
            });
          }
          // setState(() {
          //   wait = false;
          // });

          MealOneItem.reservations = [];
          MealOneItem.annulations = [];
          count1 = 0;
          count2 = 0;
          setState(() {
            check_all = false;
            wait = false;
          });
        });
      }
    }
  }

  reserve(context) async {
    if (wait == false) {
      if (MealOneItem.reservations.length == 0) {
        MealOneItem.annulations.length==0 ? ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Aucun repas n'est sélectionné"))) : ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Les repas sélectionnés sont déjà réservés")));
        // setState(() {
        //   wait = false;
        // });
      } else {
          setState(() {
            wait = true;
          });
          await makeReservationConf(widget._userId, widget._studentId, widget._token,
              MealOneItem.reservations.join(","))
              .then((val) {
                for(MealOneItem meal in listmeals){
                  meal.meals.forEach((val) {
                    if (MealOneItem.reservations.contains(val.pricemeal_id))
                      setState(() {
                        val.is_student_reserved = true;
                        val.check = false;
                      });
                  });
                }
            MealOneItem.reservations = [];
            MealOneItem.annulations = [];
            count1 = 0;
            count2 = 0;

            setState(() {
              check_all = false;
              wait = false;
            });
          });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    // ScreenUtil.instance = ScreenUtil(width: 375, height: 812)..init(context);

    // TODO: implement build
    return Scaffold(
      appBar: listKey.isNotEmpty
          ? AppBar(
              // titleSpacing: 0.0,
              elevation: 0.0,
              backgroundColor: Colors.white,
              leading: Container(
                  padding: EdgeInsets.only(left: 28.0, top: 10),
                  child:
                      // InkWell(
                      //   child: Container(
                      //     height: 18.h,
                      //     width: 18.h,
                      //     decoration: BoxDecoration(
                      //       border: Border.all(color: Fonts.border_col,style: BorderStyle.solid),
                      //       borderRadius: BorderRadius.all(Radius.circular(4.r))
                      //     ),
                      //     child: check_all == true ?  Center(child: Icon(Icons.check, size: 13.r,color: Fonts.col_app_grey,)) :Container(),
                      //   ),
                      //   onTap: (){
                      //     print(check_all);
                      //     change(check_all);
                      //     print(check_all);
                      //   },
                      // ),

                      new Checkbox(
                    splashRadius: 10.r,
                    value: check_all,
                    onChanged: (value) {
                      print(check_all);
                      SelectAll();

                      /// a modifier
                      // change(value);

                      print(check_all);
                    },
                  )),
              toolbarHeight: 170.h,

              actions: wait == true
                  ? [CupertinoActivityIndicator(), Container(width: 24.w)]
                  : <Widget>[],
              titleSpacing: 2.0,
              title: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: GestureDetector(
                      onTap: (){
                        SelectAll();
                      },
                      child: Text(
                        "Sélectionner tous",
                        style: TextStyle(
                            color: Fonts.col_app_grey, fontSize: 12.0.sp),
                      ),
                    ),
                  ),
                  Expanded(child: Container()),
                  ButtonTheme(
                      minWidth: 65.0.w,
                      height: 27.0.h,
                      child: RaisedButton(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14)),
                          color: Fonts.col_green,
                          padding: EdgeInsets.all(0),
                          onPressed: () {
                            // ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Prochainement")));
                            /// a modifier
                            reserve(context);
                          },
                          child: Text(
                            "Réserver",
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 12.0.sp,
                                fontWeight: FontWeight.w500),
                          ))),
                  SizedBox(
                    width: 10.w,
                  ),
                  Container(
                      width: 65.0.w,
                      height: 27.0.h,
                      child: RaisedButton(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14.r)),
                          color: Fonts.col_app_red,
                          padding: EdgeInsets.all(0),
                          child: Text(
                            "Annuler",
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 12.0.sp,
                                fontWeight: FontWeight.w600),
                          ),
                          onPressed: () {
                            // ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Prochainement")));
                            /// a modifier
                            annuler();
                          })),
                  SizedBox(
                    width: 22.w,
                  ),
                ],
              ),
              bottom: listKey.isNotEmpty
                  ? preferredSize(ScreenUtil().setHeight(108.0.h))
                  : PreferredSize(preferredSize: Size.fromHeight(0.1.h)),
            )
          : PreferredSize(
              preferredSize: Size.fromHeight(1),
              child: Container(width: 0.0, height: 0.0))

      /*elevation: 0,
              backgroundColor: Colors.white,
              iconTheme: IconThemeData(color: Colors.white),
              bottom: preferredSize(20.0),*/
      ,
      // floatingActionButton: FloatingActionButton(
      //   heroTag: null,
      //   highlightElevation: 7.0,
      //
      //   elevation: 0.0,
      //   //iconSize: 62,
      // backgroundColor: Fonts.col_app,
      // onPressed: () {
      // /*
      //
      //       [  widget._userId,
      //                     widget._studentId,
      //                     widget._token,
      //                     _formaterDate(date_debut),
      //                     _formaterDate(date_fin),sel_id]
      //        */
      //   print("fillter");
      //
      // filter_meal();
      // },
      // child: Container(
      // decoration: BoxDecoration(
      // color: Fonts.col_app,
      // borderRadius: BorderRadius.all(Radius.circular(14.r))
      // ),
      // width: 60.w,
      // height: 60.h,
      // child: Padding(
      // padding: EdgeInsets.all(8),
      //     child: Icon(Icons.add, color: Colors.white, size: 40.r)),
      //
      // ),
      // ),
      key: _scaffoldKey,
      body: loading
          ? Container(
              color: Colors.white,
              child: Center(
                child: CircularProgressIndicator(),
              ),
            )
          : listmeals.isNotEmpty
              ? Container(
                  color: Colors.white,
                  child: new ListView.builder(
                      itemCount: listmeals.length,
                      itemBuilder: (context, index) {
                        return MealDayWidget(listmeals[index]);
                      }),
                )
              : Container(
                  color: Colors.white,
                  child: Center(child: Text("Aucune réservation !"))),
    );
  }

  List<int> priceIds = [];
  List composantId = [];

  //List<bool> checklist = [];
  int count1 = 0;
  int count2 = 0;

/*Widget _builReservationList(String dd) {
    Widget reservationCards;
    List<Map<String, dynamic>> vv = [];
      listmeals[0][dd].forEach((val) {
        vv.add(val);
      });

    if (vv.length > 0) {
      Container(
          child: reservationCards = Column(
              children: vv
                  .map((Map<String, dynamic> val) => Container(
                      decoration: BoxDecoration(
                          border: Border(bottom: BorderSide(width: 0.2))),
                      child: Slidable(
                        delegate: new SlidableDrawerDelegate(),
                        actionExtentRatio: 0.25,
                        child: Container(
                            padding: EdgeInsets.all(16.0),
                            child: Row(children: <Widget>[
                              // Text(val["pricemeal_id"].toString()),
                              val["is_student_reserved"] == true
                                  ? Icon(
                                      Icons.check,
                                      color: Colors.blue,
                                    )
                                  : Container(),
                              Text(
                                "${val["meal"]}",
                              )
                            ])),
                        /*CheckboxListTile(
                            activeColor: Colors.green,
                            controlAffinity: ListTileControlAffinity.leading,
                            value: val["is_student_reserved"],
                            onChanged: (value) {


                            },
                            secondary: Text("${val["price"]} DHS"),
                            title: Text(
                              "${val["meal"]}",
                            ))*/

                        secondaryActions: val["is_student_reserved"] == true
                            ? <Widget>[
                                new IconSlideAction(
                                  caption: 'Annuler',
                                  color: Colors.redAccent,
                                  icon: Icons.cancel,
                                  onTap: () {
                                    setState(() {
                                      String ticket =
                                          val["ticket_id"].toString();
                                      makeCancel(
                                              widget._userId,
                                              widget._studentId,
                                              widget._token,
                                              ticket)
                                          .then((_) {
                                        val["is_student_reserved"] = false;
                                      });
                                    });
                                  },
                                ),
                              ]
                            : <Widget>[
                                new IconSlideAction(
                                  caption: 'Réserver',
                                  color: Colors.green,
                                  icon: Icons.check_circle,
                                  onTap: () {
                                    print(val["pricemeal_id"].toString());

                                    makeReservationConf(
                                            widget._userId,
                                            widget._studentId,
                                            widget._token,
                                            val["pricemeal_id"].toString())
                                        .then((_) {
                                      if (reservationData["result"] == true) {
                                        val["is_student_reserved"] = true;
                                      }
                                    });

                                    /* setState(() {
                            String id =
                            val["pricemeal_id"].toString();
                            makeReservationConf(
                                widget._userId,
                                widget._studentId,
                                widget._token,
                                id)
                                .then((_) {
                              if (reservationData["result"] == true) {
                                val["is_student_reserved"] = true;
                              }
                            });
                          });*/
                                  },
                                ),
                              ],
                      )))
                  .toList()));
    } else {
      reservationCards = Container();
    }
    return reservationCards;
  }*/

/*

  */
}
/*ListTile(
                        onTap: () {
                          getMealsDay(
                              widget._userId,
                              widget._studentId,
                              widget._token,
                              "${listKey[index]}",
                              "${addDays(listKey[index], 7)}");
                        },
                        leading: Icon(
                          Icons.date_range,
                          color: Colors.white,
                        ),
                        title: new Text(
                          "${_formatDate(listKey[index])}",
                          style: TextStyle(color: Colors.white, fontSize: 18.0),
                        ),
                        trailing: Icon(
                          Icons.keyboard_arrow_right,
                          color: Colors.white,
                        ),
                      ),*/
