import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:ifdconnect/models/Mealcal.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:ifdconnect/restauration/widgets/meal_widget.dart';
import 'package:ifdconnect/services/Fonts.dart';
import 'package:timeago/timeago.dart' as ta;
import 'package:intl/intl.dart';

class MealDayWidget extends StatefulWidget {
  MealDayWidget(this.meal, {Key key}) : super(key: key);
  MealOneItem meal;

  @override
  _MealDayWidgetState createState() => _MealDayWidgetState();
}

class _MealDayWidgetState extends State<MealDayWidget> {
  @override
  Widget build(BuildContext context) {
    /* Widget _builBatchList(String dd) {
      /*Widget timeCards;
      List<MealCal> vv = [];
      listmeals[0][dd].forEach((val) {
        vv.add(val);

        i = listmeals[0][dd].indexOf(val);
      });

      if (vv.length > 0) {*/
      return   Container(
            child:  Container(
              padding: EdgeInsets.symmetric(horizontal: 13.w, vertical: 5.h),
              margin: EdgeInsets.symmetric(horizontal: 20.w, vertical: 5.h),
              decoration: BoxDecoration(
                  color: Fonts.col_cl,
                  border: Border.all(width: 1, color: Fonts.col_app_fon),
                  borderRadius: BorderRadius.all(Radius.circular(18.r))),

              // color: Colors.green,

              child: Column(
                  children: vv
                      .map(
                        (MealCal val) => Container(
                      child: Column(children: <Widget>[
                        listmeals[0][dd].indexOf(val) == 0
                            ? Container(
                          // color: Color(0xffFAFAFA),

                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              Container(
                                child: Row(
                                  children: [
                                    Container(
                                      width: 18.w,
                                    ),
                                    Image.asset(
                                      "images/appointment.png",
                                      color: Fonts.col_app_fon,
                                      width: 15.5.w,
                                      height: 17.5.h,
                                    ),
                                    Container(
                                      width: 10.0.w,
                                    ),
                                   ///jijiji
                              ),
                              Expanded(child: Container()),
                              InkWell(
                                child: InkWell(
                                  child: Icon(
                                    val.more_dtaills
                                        ? Icons.arrow_drop_up_outlined
                                        : Icons.arrow_drop_down,
                                    size: 30.r,
                                    color: Fonts.col_app_fonn,
                                  ),
                                ),
                                onTap: () {
                                  if (val.show == true) {
                                    setState(() {
                                      val.show = false;
                                    });

                                    print(val.more_dtaills);
                                  } else {
                                    setState(() {
                                      val.show = true;
                                    });

                                    print(val.more_dtaills);
                                  }
                                },
                              )
                            ],
                          ),
                        )
                            : listmeals[0][dd][i].date ==
                            listmeals[0][dd][i - 1].date
                            ? Container(
                          color: Fonts.col_cl,
                        )
                            : Container(
                          color: Color(0xffFAFAFA),
                          child: Row(
                            children: <Widget>[
                              Image.asset(
                                "images/appointment.png",
                                color: Fonts.col_app,
                                width: 18.0.w,
                                height: 18.0.h,
                              ),
                              Container(
                                width: 8.0.w,
                              ),
                              Container(
                                width: 4.0.w,
                              ),
                              new Text(
                                val.date,
                              )
                            ],
                          ),
                        ),
                        val.show == false?Container():  Column(
                          children: [
                            Slidable(
                              controller: ctrl,
                              //key: keys,
                              enabled: true,
                              actionPane: SlidableDrawerActionPane(),
                              // delegate: new SlidableDrawerDelegate(),
                              actionExtentRatio: 0.25,
                              secondaryActions: val.date == true
                                  ? <Widget>[
                                new IconSlideAction(
                                  caption: 'Annuler',
                                  color: Fonts.col_app_red,
                                  icon: Icons.cancel,
                                  onTap: () {
                                    setState(() {
                                      String ticket =
                                      val.ticket_id.toString();
                                      makeCancel(
                                          widget._userId,
                                          widget._studentId,
                                          widget._token,
                                          ticket)
                                          .then((_) {
                                        val.is_student_reserved =
                                        false;
                                      });
                                    });
                                  },
                                ),
                              ]
                                  : <Widget>[
                                new IconSlideAction(
                                  caption: 'Réserver',
                                  color: Colors.black,
                                  icon: Icons.check_circle,
                                  onTap: () {
                                    makeReservationConf(
                                        widget._userId,
                                        widget._studentId,
                                        widget._token,
                                        val.pricemeal_id
                                            .toString())
                                        .then((_) {
                                      if (reservationData["result"] ==
                                          true) {
                                        val.is_student_reserved =
                                        true;
                                      }
                                    });

                                    /* setState(() {
                                String id =
                                val["pricemeal_id"].toString();
                                makeReservationConf(
                                    widget._userId,
                                    widget._studentId,
                                    widget._token,
                                    id)
                                    .then((_) {
                                  if (reservationData["result"] == true) {
                                    val["is_student_reserved"] = true;
                                  }
                                });
                              });*/
                                  },
                                ),
                              ],
                              child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.all(
                                        Radius.circular(18.r)),
                                    color: val.is_student_reserved
                                        ? Fonts.col_green
                                        : Fonts.col_cl,
                                  ),
                                  child: Container(
                                      padding: EdgeInsets.only(top: 8.0.h),
                                      decoration: BoxDecoration(),
                                      child: Column(children: <Widget>[
                                        Row(
                                            mainAxisAlignment:
                                            MainAxisAlignment.start,
                                            children: <Widget>[
                                              /*  activeColor: containsElement(val["index"])
                                        ? Colors.grey
                                        : Colors.green,*/
                                              /*IconButton(
                                                  padding: EdgeInsets.all(0.0),
                                                  onPressed: () {
                                                    Slidable.of(context)?.close();
                                                  },
                                                  icon: Icon(Icons.arrow_back),
                                                )*/
                                              isBefore(val.date)
                                                  ? Container(
                                                width: 18.w,
                                                height: 18.h,
                                              )
                                                  : InkWell(
                                                child: Row(
                                                  children: [
                                                    Container(
                                                      width: 18.w,
                                                      height: 18.h,
                                                      // padding: EdgeInsets.all(4),
                                                      decoration: BoxDecoration(
                                                          border: Border.all(
                                                              color: Fonts
                                                                  .col_app_grey,
                                                              width: 1
                                                                  .w),
                                                          borderRadius:
                                                          BorderRadius.all(
                                                              Radius.circular(4.r))),
                                                      child: val.check ==
                                                          true
                                                          ? Center(
                                                          child:
                                                          Icon(
                                                            Icons
                                                                .check,
                                                            color: Fonts
                                                                .col_app_grey,
                                                            size: 15
                                                                .r,
                                                          ))
                                                          : Container(),
                                                    ),
                                                    Container(
                                                      width: 13.w,
                                                    ),
                                                    Row(
                                                      children: <
                                                          Widget>[
                                                        // Image.asset(
                                                        //   "images/dish.png",
                                                        //   color: Fonts.col_app,
                                                        //   width: 18.0.w,
                                                        //   height: 18.0.h,
                                                        // ),
                                                        // Container(
                                                        //   width: 8.0.w,
                                                        // ),
                                                        Text(
                                                          "${val.meal}",
                                                          style: TextStyle(
                                                              fontFamily:
                                                              "Helvetica",
                                                              color: Fonts
                                                                  .col_text,
                                                              fontWeight:
                                                              FontWeight
                                                                  .w500,
                                                              fontSize:
                                                              18.sp),
                                                        ),
                                                      ],
                                                    ),
                                                    // Expanded(
                                                    //   child: Container(),
                                                    // ),
                                                    Container(
                                                      width: 10.0.w,
                                                    ),
                                                    Text(
                                                        "${val.price} DHS",
                                                        style: TextStyle(
                                                            fontWeight:
                                                            FontWeight
                                                                .bold,
                                                            color: Fonts
                                                                .col_app_fonn,
                                                            fontSize:
                                                            12.sp)),
                                                    Container(
                                                      width: 8.w,
                                                    ),
                                                  ],
                                                ),
                                                onTap: () {
                                                  print(val);

                                                  setState(() {
                                                    if (val.check ==
                                                        false) {
                                                      if (val.is_student_reserved ==
                                                          true) {
                                                        count1 =
                                                            count1 +
                                                                1;
                                                        print(count1);
                                                      } else {
                                                        count2 =
                                                            count2 +
                                                                1;
                                                      }
                                                      val.check =
                                                      true;

                                                      priceIds.add(int
                                                          .parse(val
                                                          .pricemeal_id
                                                          .toString()));
                                                      if (!tikeckids
                                                          .contains(val
                                                          .ticket_id) &&
                                                          val.ticket_id
                                                              .toString() !=
                                                              "null") {
                                                        tikeckids.add(
                                                            val.ticket_id);
                                                      }
                                                    } else {
                                                      if (val
                                                          .is_student_reserved) {
                                                        count2 =
                                                            count2 -
                                                                1;
                                                      } else {
                                                        count1 =
                                                            count1 -
                                                                1;
                                                      }

                                                      val.check =
                                                      false;
                                                      priceIds.remove(
                                                          int.parse(val
                                                              .pricemeal_id
                                                              .toString()));
                                                      if (tikeckids
                                                          .contains(val
                                                          .ticket_id)) {
                                                        tikeckids
                                                            .remove(val
                                                            .ticket_id);
                                                      }
                                                    }
                                                  });
                                                },
                                              ),
                                              Expanded(
                                                child: Container(),
                                              ),
                                              Container(
                                                  decoration: BoxDecoration(
                                                      color: Colors.white,
                                                      border: Border.all(
                                                          width: 1.w, //
                                                          color: val.is_student_reserved ==
                                                              false
                                                              ? Fonts
                                                              .col_app_red
                                                              : Fonts
                                                              .col_green
                                                        //                 <--- border width here
                                                      ),
                                                      borderRadius:
                                                      BorderRadius.all(
                                                        Radius.circular(
                                                            80.0.r),
                                                      )),
                                                  padding:
                                                  EdgeInsets.all(3.r),
                                                  child: Center(
                                                      child: Text(
                                                        val.is_student_reserved
                                                            ? "R"
                                                            : "NR",
                                                        style: TextStyle(
                                                            fontSize: 12.0.sp,
                                                            fontWeight:
                                                            FontWeight.w900,
                                                            color: val.is_student_reserved ==
                                                                false
                                                                ? Fonts
                                                                .col_app_red
                                                                : Fonts
                                                                .col_green),
                                                      ))),
                                              Container(width: 14.w)
                                            ]),
                                        Container(
                                          height: 14.h,
                                        ),

                                        Container(
                                          // color: Colors.red,
                                          child: Row(
                                            mainAxisAlignment:
                                            MainAxisAlignment.start,
                                            crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // color: Colors.green,
                                                width: val.type_composant
                                                    .length ==
                                                    0
                                                    ? MediaQuery.of(context)
                                                    .size
                                                    .width *
                                                    0
                                                    : MediaQuery.of(context)
                                                    .size
                                                    .width *
                                                    0.4,
                                                child: Column(
                                                  mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .start,
                                                  crossAxisAlignment:
                                                  CrossAxisAlignment
                                                      .start,
                                                  children: [
                                                    //Composants

                                                    val.type_composant
                                                        .length ==
                                                        0
                                                        ? Container()
                                                        : Container(
                                                      child: Row(
                                                        children: [
                                                          Container(
                                                            height:
                                                            15.w,
                                                          ),
                                                          Container(
                                                              child:
                                                              Text(
                                                                "Composants :",
                                                                style:
                                                                TextStyle(
                                                                  fontWeight:
                                                                  FontWeight.bold,
                                                                  fontSize:
                                                                  12.sp,
                                                                  color: Fonts
                                                                      .col_app_grey,
                                                                  fontFamily:
                                                                  "Helvetica",
                                                                ),
                                                              )),
                                                        ],
                                                      ),
                                                    ),
                                                    Container(
                                                      height: 10.w,
                                                    ),

                                                    Column(
                                                        children: val
                                                            .type_composant
                                                            .map<Widget>(
                                                                (result) {
                                                              // List <Type_composant> vallll = List <Type_composant>.from(result.composants.map((type)=> Type_composant.fromDoc(type)).toList()) ;
                                                              return Container(
                                                                margin:
                                                                EdgeInsets.only(
                                                                    bottom:
                                                                    10.h),
                                                                child: Column(
                                                                  children: [
                                                                    Row(
                                                                      mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                      children: [
                                                                        // Container(width: 20.w,),
                                                                        Container(
                                                                          child:
                                                                          Text(
                                                                            result.name +
                                                                                " :",
                                                                            style:
                                                                            TextStyle(
                                                                              fontWeight:
                                                                              FontWeight.w100,
                                                                              fontSize:
                                                                              12.sp,
                                                                              color:
                                                                              Fonts.col_app_grey,
                                                                              fontFamily:
                                                                              "Helvetica",
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        // Container(width: 15.w,),

                                                                        Expanded(
                                                                            child:
                                                                            Container()),

                                                                        /*new Container(
                                                               color: Colors.blue,
                                                                child: Container(
                                                                    padding: EdgeInsets.symmetric(vertical: 3.w,horizontal: 8.h),
                                                                    decoration: BoxDecoration(borderRadius: BorderRadius.all(Radius.circular(8.r)),
                                                                        border: Border.all(style: BorderStyle.solid,color: Fonts.border_col,width: 0.5)),
                                                                    height: 25.h,
                                                                    width: 200.w,
                                                                    alignment: Alignment.center,
                                                                    child: new FixDropDown(
                                                                        style: TextStyle(color: Colors.black),
                                                                        iconSize: 32.0,
                                                                        isDense: false,
                                                                        items: result.composants.map((value) {
                                                                          return new FixDropdownMenuItem(
                                                                            value: value,
                                                                            child: new Text(
                                                                              value.name,
                                                                              maxLines: 2,
                                                                              softWrap: true,
                                                                              style: TextStyle( color: Colors.black),
                                                                            ),
                                                                          );
                                                                        }).toList(),
                                                                        hint: new Text(
                                                                          composants_id != ""
                                                                              ? composants_id
                                                                              : "Plat",
                                                                          maxLines: 1,
                                                                          softWrap: true,
                                                                          style: new TextStyle(color: Colors.white),
                                                                        ),
                                                                        onChanged: (value) {
                                                                          setState(() {
                                                                            composants_id = value.name;
                                                                           // error = "";
                                                                          });
                                                                        })))*/

                                                                        Container(
                                                                          padding: EdgeInsets.symmetric(
                                                                              vertical: 3
                                                                                  .w,
                                                                              horizontal:
                                                                              8.h),
                                                                          decoration: BoxDecoration(
                                                                              borderRadius: BorderRadius.all(Radius.circular(8
                                                                                  .r)),
                                                                              border: Border.all(
                                                                                  style: BorderStyle.solid,
                                                                                  color: Fonts.border_col,
                                                                                  width: 0.5)),
                                                                          height:
                                                                          25.h,
                                                                          width:
                                                                          100.w,
                                                                          alignment:
                                                                          Alignment
                                                                              .center,
                                                                          child:
                                                                          DropdownButtonHideUnderline(
                                                                            child:
                                                                            DropdownButton(
                                                                              hint:
                                                                              Text(result.name),
                                                                              value:
                                                                              composants_id,
                                                                              isExpanded:
                                                                              true,
                                                                              icon:
                                                                              const Icon(
                                                                                Icons.arrow_drop_down,
                                                                                color:
                                                                                Fonts.col_app_grey,
                                                                              ),
                                                                              elevation:
                                                                              0,
                                                                              style:
                                                                              TextStyle(
                                                                                fontWeight:
                                                                                FontWeight.w500,
                                                                                fontSize:
                                                                                11.sp,
                                                                                color:
                                                                                Fonts.col_app_grey,
                                                                                fontFamily:
                                                                                "Helvetica",
                                                                              ),
                                                                              onChanged:
                                                                                  (newValue) {
                                                                                print("yessssssssss");
                                                                                print(newValue);
                                                                                /*setState(() {
                                                                      composants_id = newValue ;
                                                                    });*/
                                                                              },
                                                                              items: result
                                                                                  .composants
                                                                                  .map((value) {
                                                                                return DropdownMenuItem<String>(
                                                                                  value: value.name,
                                                                                  child: Text(
                                                                                    value.name,
                                                                                    style: TextStyle(
                                                                                      fontWeight: FontWeight.w500,
                                                                                      fontSize: 10.sp,
                                                                                      color: Fonts.col_app_grey,
                                                                                      fontFamily: "Helvetica",
                                                                                    ),
                                                                                  ),
                                                                                );
                                                                              }).toList(),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ],
                                                                ),
                                                              );
                                                            }).toList()),

                                                    //End Composants
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                width: val.type_repas
                                                    .length ==
                                                    0
                                                    ? MediaQuery.of(context)
                                                    .size
                                                    .width *
                                 @                   0
                                                    : MediaQuery.of(context)
                                                    .size
                                                    .width *
                                                    0.4,
                                                child: Column(
                                                  mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .start,
                                                  crossAxisAlignment:
                                                  CrossAxisAlignment
                                                      .start,
                                                  children: [
                                                    //  Extra

                                                    val.type_repas.length ==
                                                        0
                                                        ? Container()
                                                        : Container(
                                                      child: Row(
                                                        children: [
                                                          // Container(width: 20.w,),
                                                          Container(
                                                            child:
                                                            Row(
                                                              children: [
                                                                Container(
                                                                  height:
                                                                  15.w,
                                                                ),
                                                                Container(
                                                                    child: Text(
                                                                      "Extra :",
                                                                      style:
                                                                      TextStyle(
                                                                        fontWeight: FontWeight.bold,
                                                                        fontSize: 12.sp,
                                                                        color: Fonts.col_app_grey,
                                                                        fontFamily: "Helvetica",
                                                                      ),
                                                                    )),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Container(
                                                      height: 10.w,
                                                    ),

                                                    Container(
                                                      // margin: EdgeInsets.only(left: 10),
                                                      child: Column(
                                                        children: val
                                                            .type_repas
                                                            .map<Widget>(
                                                                (type_repas) {
                                                              // List <Type_repas> vallll = List <Type_repas>.from(val.map((type)=> Type_repas.fromDoc(type)).toList()) ;
                                                              print(
                                                                  "**********");
                                                              print(val.check);
                                                              return Container(
                                                                  padding: EdgeInsets
                                                                      .only(
                                                                      bottom:
                                                                      10.h),
                                                                  child: Row(
                                                                    children: [
                                                                      InkWell(
                                                                        child:
                                                                        Container(
                                                                          padding:
                                                                          EdgeInsets.symmetric(vertical: 5.h),
                                                                          // color: Colors.red,
                                                                          child:
                                                                          Row(
                                                                            children: [
                                                                              Container(
                                                                                width: 16.w,
                                                                                height: 16.h,
                                                                                // padding: EdgeInsets.all(4),
                                                                                decoration: BoxDecoration(border: Border.all(color: Fonts.col_app_grey, width: 1), borderRadius: BorderRadius.all(Radius.circular(4.r))),
                                                                                child: type_repas.check == true
                                                                                    ? Center(
                                                                                    child: Icon(
                                                                                      Icons.check,
                                                                                      color: Fonts.col_app_grey,
                                                                                      size: 13.r,
                                                                                    ))
                                                                                    : Container(),
                                                                              ),
                                                                              Container(
                                                                                width: 10.w,
                                                                              ),
                                                                              // Container(
                                                                              //   width: 8.0,
                                                                              // ),
                                                                              Text(
                                                                                "${type_repas.name}",
                                                                                style: TextStyle(
                                                                                  fontWeight: FontWeight.w100,
                                                                                  fontSize: 12.sp,
                                                                                  color: Fonts.col_app_grey,
                                                                                  fontFamily: "Helvetica",
                                                                                ),
                                                                              ),
                                                                              Container(
                                                                                width: 10.0.w,
                                                                              ),
                                                                            ],
                                                                          ),
                                                                          // color: Colors.red,
                                                                        ),
                                                                        onTap:
                                                                            () {
                                                                          setState(
                                                                                  () {
                                                                                print("##########");

                                                                                print(type_repas.check);

                                                                                if (type_repas.check ==
                                                                                    false) {
                                                                                  type_repas.check = true;
                                                                                  if (val.check == false) {
                                                                                    // val.check = true ;
                                                                                    if (val.is_student_reserved == true) {
                                                                                      count1 = count1 + 1;
                                                                                      print(count1);
                                                                                    } else {
                                                                                      count2 = count2 + 1;
                                                                                    }
                                                                                    val.check = true;

                                                                                    mealcal.add(
                                                                                      {
                                                                                        "MealCal": "${int.parse(val.pricemeal_id.toString())}"
                                                                                      },
                                                                                    );

                                                                                    priceIds.add(int.parse(val.pricemeal_id.toString()));
                                                                                    if (!tikeckids.contains(val.ticket_id) && val.ticket_id.toString() != "null") {
                                                                                      tikeckids.add(val.ticket_id);
                                                                                    }
                                                                                  }
                                                                                  // composantId.add(int.parse(
                                                                                  //     type_repas.id.toString()));
                                                                                  composantId.add({
                                                                                    "pricemeal_id": int.parse(val.pricemeal_id.toString()),
                                                                                    "id_extra": int.parse(type_repas.id.toString())
                                                                                  });
                                                                                  print(composantId);
                                                                                  print("-----");
                                                                                  print(priceIds);
                                                                                } else {
                                                                                  type_repas.check = false;
                                                                                  composantId.remove(int.parse(type_repas.id.toString()));
                                                                                  print(composantId);
                                                                                  print("-----");
                                                                                  print(priceIds);
                                                                                }
                                                                                print(type_repas.check);
                                                                              });
                                                                        },
                                                                      ),
                                                                      Expanded(
                                                                          child:
                                                                          Container()),
                                                                      Text(
                                                                          "${type_repas.price} DHS",
                                                                          style: TextStyle(
                                                                              fontWeight: FontWeight.w800,
                                                                              color: Fonts.col_app_fonn,
                                                                              fontSize: 12.sp)),
                                                                    ],
                                                                  ));
                                                            }).toList(),
                                                      ),
                                                    ),

                                                    // End Extra
                                                  ],
                                                ),
                                              )
                                            ],
                                          ),
                                        ),
                                        // Container(height: 10.h,),
                                      ]))),
                            ),

                            // listmeals[0][dd].indexOf(val) == 0
                            //     ?
                            val.meal == "diner "
                                ? Container()
                                : Divider(
                              color: Fonts.col_app_grey,
                              thickness: 0.5.r,
                            )
                          ],
                        )
                        //     : listmeals[0][dd][i].date ==
                        //     listmeals[0][dd][i - 1].date
                        //     ? Container()
                        //     :
                        // Divider(color: Fonts.col_app_red,thickness: 1,),
                      ]),
                    ),
                  )
                      .toList()),
            ));
     /* } else {
        timeCards = Container();
      }
      return timeCards;
    }*/

    */
    return Container(
        padding: EdgeInsets.symmetric(horizontal: 13.w, vertical: 5.h),
        margin: EdgeInsets.symmetric(horizontal: 20.w, vertical: 5.h),
        decoration: BoxDecoration(
            color: Fonts.col_cl,
            border: Border.all(width: 1, color: Fonts.col_app_fon),
            borderRadius: BorderRadius.all(Radius.circular(18.r))),

        // color: Colors.green,

        child: Theme(
            data: ThemeData().copyWith(dividerColor: Colors.transparent),
            child: ListTileTheme(
                contentPadding: EdgeInsets.all(0),
                dense: true,
                horizontalTitleGap: 0.0,
                minLeadingWidth: 0,
                minVerticalPadding: 2.h,
                child: new ExpansionTile(
                    backgroundColor: Colors.white,
                    initiallyExpanded: true,
                    tilePadding: EdgeInsets.only(left: 0, top: 0),
                    children:
                        widget.meal.meals.map((e) => MealWidget(e)).toList(),
                    //tilePadding: EdgeInsets.all(4.w),
                    title: Container(
                      child: new Text(
                        new DateFormat('dd/MM/yyyy')
                            .format(DateTime.parse(widget.meal.date)),
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16.sp,
                            fontFamily: "Helvetica",
                            color: Fonts.col_app_fon),
                      ),
                    )))));
  }
}
