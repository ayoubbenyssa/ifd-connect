import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:ifdconnect/models/Mealcal.dart';
import 'package:ifdconnect/services/Fonts.dart';

class MealWidget extends StatefulWidget {
  MealWidget(this.meal, {Key key}) : super(key: key);
  MealCal meal;

  @override
  _MealWidgetState createState() => _MealWidgetState();
}

class _MealWidgetState extends State<MealWidget> {
  String composants_id;
  List<String> values;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    setState(() {
      values = List<String>.generate(widget.meal.type_composant.length, (int index) => '');
      // values = List<String>.generate(widget.meal.type_composant.length, (int index) => widget.meal.type_composant[index].composants[0].name.toString()??'');

    });
  }

  @override
  Widget build(BuildContext context) {
    Widget header = Row(mainAxisAlignment: MainAxisAlignment.start, children: [
      InkWell(
        onTap: (){
          setState(() {
            widget.meal.check = !widget.meal.check;
            if (widget.meal.check) {
              widget.meal.is_student_reserved ? MealOneItem.annulations.add(widget.meal.ticket_id) : MealOneItem.reservations.add(widget.meal.pricemeal_id);
            }
            else
              widget.meal.is_student_reserved ? MealOneItem.annulations.remove(widget.meal.ticket_id) : MealOneItem.reservations.remove(widget.meal.pricemeal_id);

          });
        },
        child: Row(
          children: [
            Container(
              width: 18.w,
              height: 18.h,
              // padding: EdgeInsets.all(4),
              decoration: BoxDecoration(
                  border: Border.all(color: Fonts.col_app_grey, width: 1.w),
                  borderRadius: BorderRadius.all(Radius.circular(4.r))),
              child: widget.meal.check == true
                  ? Center(
                      child: Icon(
                      Icons.check,
                      color: Fonts.col_app_grey,
                      size: 15.r,
                    ))
                  : Container(),
            ),
            Container(width: 16.w),
            Text(
              widget.meal.meal,
              style: TextStyle(
                  fontSize: 20.6.sp, fontFamily: "Hbold", color: Fonts.col_app_grey),
            ),
          ],
        ),
      ),
      Expanded(
        child: Container(),
      ),
      if(widget.meal.is_student_reserved) Container(
        decoration: BoxDecoration(
            color: Colors.white,
            border: Border.all(
                width: 1.w, //
                color: Fonts.col_green
              //                 <--- border width here
            ),
            borderRadius:
            BorderRadius.all(
              Radius.circular(80.0.r),
            )),
        padding: EdgeInsets.all(3.r),
        child: Text(
          "R",
          style: TextStyle(
              fontSize: 12.0.sp,
              fontWeight: FontWeight.w900,
              color:Fonts.col_green
          ),
        ),
      ),
      Expanded(
        child: Container(),
      ),
      Container(
          width: 78.w,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SvgPicture.asset("assets/icons/price.svg"),
              Container(
                width: 10.w,
              ),
              Text(
                widget.meal.price.toString() + " Dhs",
                style: TextStyle(
                    fontSize: 13.0.sp,
                    fontFamily: "Hbold",
                    color: Fonts.col_app),
              )
            ],
          ))
    ]);

    Widget composants_widget = Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(height: 16.h),
        widget.meal.type_composant.length == 0
            ? Container()
            : Text("Composants",
                style: TextStyle(
                    fontSize: 15.6.sp,
                    fontFamily: "Hbold",
                    color: Fonts.col_app_grey)),
        Container(height: 10.h),
        Column(
            children: widget.meal.type_composant.map<Widget>((result) {
          // List <Type_composant> vallll = List <Type_composant>.from(result.composants.map((type)=> Type_composant.fromDoc(type)).toList()) ;
          return Container(
            margin: EdgeInsets.only(bottom: 10.h),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    // Container(width: 20.w,),
                    Container(
                      child: Text(
                        result.name + " :",
                        style: TextStyle(
                          fontWeight: FontWeight.w100,
                          fontSize: 12.sp,
                          color: Fonts.col_app_grey,
                          fontFamily: "Helvetica",
                        ),
                      ),
                    ),
                    // Container(width: 15.w,),

                    Expanded(child: Container()),

                    /*new Container(
                                                               color: Colors.blue,
                                                                child: Container(
                                                                    padding: EdgeInsets.symmetric(vertical: 3.w,horizontal: 8.h),
                                                                    decoration: BoxDecoration(borderRadius: BorderRadius.all(Radius.circular(8.r)),
                                                                        border: Border.all(style: BorderStyle.solid,color: Fonts.border_col,width: 0.5)),
                                                                    height: 25.h,
                                                                    width: 200.w,
                                                                    alignment: Alignment.center,
                                                                    child: new FixDropDown(
                                                                        style: TextStyle(color: Colors.black),
                                                                        iconSize: 32.0,
                                                                        isDense: false,
                                                                        items: result.composants.map((value) {
                                                                          return new FixDropdownMenuItem(
                                                                            value: value,
                                                                            child: new Text(
                                                                              value.name,
                                                                              maxLines: 2,
                                                                              softWrap: true,
                                                                              style: TextStyle( color: Colors.black),
                                                                            ),
                                                                          );
                                                                        }).toList(),
                                                                        hint: new Text(
                                                                          composants_id != ""
                                                                              ? composants_id
                                                                              : "Plat",
                                                                          maxLines: 1,
                                                                          softWrap: true,
                                                                          style: new TextStyle(color: Colors.white),
                                                                        ),
                                                                        onChanged: (value) {
                                                                          setState(() {
                                                                            composants_id = value.name;
                                                                           // error = "";
                                                                          });
                                                                        })))*/

                    Container(
                      padding:
                          EdgeInsets.symmetric(vertical: 3.w, horizontal: 8.h),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.all(Radius.circular(8.r)),
                          border: Border.all(
                              style: BorderStyle.solid,
                              color: Fonts.border_col,
                              width: 0.5)),
                      height: 25.h,
                      width: 100.w,
                      alignment: Alignment.center,
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton(
                          hint: Text(result.name),
                          value: result.composant_choisi,
                          isExpanded: true,
                          icon: const Icon(
                            Icons.arrow_drop_down,
                            color: Fonts.col_app_grey,
                          ),
                          elevation: 0,
                          style: TextStyle(
                            fontWeight: FontWeight.w500,
                            fontSize: 11.sp,
                            color: Fonts.col_app_grey,
                            fontFamily: "Helvetica",
                          ),
                          onChanged: (newValue) {
                            setState(() {
                              result.composant_choisi = newValue;
                            });
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Les composants seront prochainement pris en considération")));
                            print("yessssssssss");
                            print(newValue);
                            /*setState(() {
                                                                      composants_id = newValue ;
                                                                    });*/
                          },
                          items: result.composants.map((value) {
                            return DropdownMenuItem<String>(
                              value: value.id.toString(),
                              child: Text(
                                value.name,
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 10.sp,
                                  color: Fonts.col_app_grey,
                                  fontFamily: "Helvetica",
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        }).toList()),
        Container(height: 12.h),
      ],
    );

    Widget extra_widget = Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(height: 16.h),
        widget.meal.type_repas.length == 0
            ? Container()
            : Text("Extra :",
                style: TextStyle(
                    fontSize: 15.6.sp,
                    fontFamily: "Hbold",
                    color: Fonts.col_app_grey)),
        Container(height: 10.h),
        Container(
          // margin: EdgeInsets.only(left: 10),
          child: Column(
            children: widget.meal.type_repas.map<Widget>((type_repas) {
              // List <Type_repas> vallll = List <Type_repas>.from(val.map((type)=> Type_repas.fromDoc(type)).toList()) ;
              print("**********");
              return Container(
                  padding: EdgeInsets.only(bottom: 10.h),
                  child: Row(
                    children: [
                      InkWell(
                        child: Container(
                          padding: EdgeInsets.symmetric(vertical: 5.h),
                          // color: Colors.red,
                          child: Row(
                            children: [
                              Container(
                                width: 16.w,
                                height: 16.h,
                                // padding: EdgeInsets.all(4),
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        color: Fonts.col_app_grey, width: 1),
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(4.r))),
                                child: type_repas.check == true
                                    ? Center(
                                        child: Icon(
                                        Icons.check,
                                        color: Fonts.col_app_grey,
                                        size: 13.r,
                                      ))
                                    : Container(),
                              ),
                              Container(
                                width: 10.w,
                              ),
                              // Container(
                              //   width: 8.0,
                              // ),
                              Text(
                                "${type_repas.name}",
                                style: TextStyle(
                                  fontWeight: FontWeight.w100,
                                  fontSize: 12.sp,
                                  color: Fonts.col_app_grey,
                                  fontFamily: "Helvetica",
                                ),
                              ),
                              Container(
                                width: 10.0.w,
                              ),
                            ],
                          ),
                          // color: Colors.red,
                        ),
                        onTap: () {
                          // setState(() {
                          //   type_repas.check = !type_repas.check;
                          // });
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Les extras seront prochainement pris en considération")));

                          /*  print("##########");

                                    print(type_repas.check);

                                    if (type_repas.check ==
                                        false) {
                                      type_repas.check = true;
                                      if (val.check == false) {
                                        // val.check = true ;
                                        if (val.is_student_reserved == true) {
                                          count1 = count1 + 1;
                                          print(count1);
                                        } else {
                                          count2 = count2 + 1;
                                        }
                                        val.check = true;

                                        mealcal.add(
                                          {
                                            "MealCal": "${int.parse(val.pricemeal_id.toString())}"
                                          },
                                        );

                                        priceIds.add(int.parse(val.pricemeal_id.toString()));
                                        if (!tikeckids.contains(val.ticket_id) && val.ticket_id.toString() != "null") {
                                          tikeckids.add(val.ticket_id);
                                        }
                                      }
                                      // composantId.add(int.parse(
                                      //     type_repas.id.toString()));
                                      composantId.add({
                                        "pricemeal_id": int.parse(val.pricemeal_id.toString()),
                                        "id_extra": int.parse(type_repas.id.toString())
                                      });
                                      print(composantId);
                                      print("-----");
                                      print(priceIds);
                                    } else {
                                      type_repas.check = false;
                                      composantId.remove(int.parse(type_repas.id.toString()));
                                      print(composantId);
                                      print("-----");
                                      print(priceIds);
                                    }
                                    print(type_repas.check);
                                  });*/
                        },
                      ),
                      Expanded(child: Container()),
                      Text("+ ${type_repas.price} DHS",
                          style: TextStyle(
                              fontWeight: FontWeight.w800,
                              fontFamily: "Hbold",
                              color: Fonts.col_green,
                              fontSize: 13.sp)),
                      Container(
                        width: 8.w,
                      )
                    ],
                  ));
            }).toList(),
          ),
        ),
        Container(height: 12.h),
      ],
    );

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        header,
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: MediaQuery.of(context).size.width * 0.4,
              child: composants_widget,
            ),
            Expanded(
                child: Container(
              width: 16.w,
            )),
            Container(
              width: MediaQuery.of(context).size.width * 0.4,
              child: extra_widget,
            )
          ],
        )
      ],
    );
  }
}
